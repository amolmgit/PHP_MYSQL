<?php
$link=mysqli_connect("localhost", "root", "");
mysqli_select_db($link, "Login");
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://w3.org/TR/html4/loose.dtd">
<html>
	<head>
		<title>Insert records</title>
		<meta http-quiv="Content-Type" content="text/html; charset=iso-8859-1">
	</head>

	<body>
		<form name="form1" action="" method="POST">
			<table>
				<tr>
					<td>Enter userid</td>
					<td><input type="text" name="t1"></td>
				</tr>
				<tr>
					<td>Enter username</td>
					<td><input type="text" name="t2"></td>
				</tr>
				<tr>
					<td>Enter password</td>
					<td><input type="text" name="t3"></td>
				</tr>
				<tr>
					<td colspan="2" align="center"><input type="submit" name="submit1" value="Insert record"></td>
				</tr>
			</table>
		</form>

<?php
		if(isset($_POST["submit1"]))
		{
		mysqli_query($link, "insert into Login values('$_POST[t1]','$_POST[t2]','$_POST[t3]')");
		}
?>
	</body>
</html>